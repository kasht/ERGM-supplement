# Function allows for specification of estimation parameters

est_control <- function(burnin = 1e+4,
                        interval = 1000,
                        num_obs = 5e+3,
                        NR_tol = 1e-8,
                        NR_max_iter = 25,
                        MCMLE_max_iter = 4,
                        MCMLE_tol = 1e-4,
                        NR_step_len = 1,
                        par_comp = FALSE,
                        par_n_cores = 2,
                        sample_size_multiplier) {


  if (is.null(sample_size_multiplier)) {
    if (num_obs > 5e+3){
      sample_size <- 5e+3
    } else {
      sample_size <- num_obs
    }
  } else { 
    sample_size <- "scale"
  }
  sim_param <- list(burnin = burnin,
                    interval = interval,
                    num_obs = sample_size,
                    sample_size_multiplier = sample_size_multiplier, 
                    stats = NULL,
                    cond_stats = NULL)


  est_param <- list(eta = NULL,
                    eta_0 = NULL,
                    eta_grad = NULL,
                    eta_fun = NULL,
                    score_val = NULL,
                    NR_tol = NR_tol,
                    NR_iter = 1,
                    NR_max_iter = NR_max_iter,
                    NR_status = FALSE,
                    step_err = 0,
                    MCMLE_iter = 1,
                    MCMLE_max_iter = MCMLE_max_iter,
                    MCMLE_tol = MCMLE_tol,
                    MCMLE_status = FALSE,
                    info_mat = NULL,
                    NR_step_len = NR_step_len,
                    NR_conv_thresh = NULL,
                    MCMLE_conv_thresh = NULL,
                    par_flag = par_comp,
                    par_n_cores = par_n_cores,
                    ML_status_fail = FALSE)

  return(list(sim_param = sim_param,
              est_param = est_param))
}
