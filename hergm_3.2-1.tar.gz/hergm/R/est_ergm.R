est_ergm <- function(net_list,
                     form,
                     initial_params,
                     controls = est_control(),
                     num_group = 1,
                     verbose = 2,
                     parameterization = "standard",
                     seeds) {
  
  # If size dependent parameterizations are to be used sort neighborhoods
  eta_init <- initial_params$init_param
  initial_se <- initial_params$init_se
  if (num_group > 1) {
    parameterization <- "multi_group"
  }
  suff_sizes <- numeric(length(net_list))
  for (i in 1:length(net_list)) { 
    cur_net <- net_list[[i]]
    form_ <- as.formula(paste("cur_net ~ ", paste(deparse(form[[3]]), collapse = "")))
    suff_sizes[i] <- length(summary(form_))
  }
  largest_ <- net_list[[which.max(suff_sizes)]]
  form_ <- update(form_, largest_ ~ .)
  model <- ergm.getmodel(form_, largest_)
  eta_map <- ergm.etamap(model) 
  model_size <- max(suff_sizes)
  if (parameterization == "standard") {
    dims <- rep_row(rbind(seq(1, model_size)), length(net_list))
    labels <- rep(1, length(net_list))
    eta_init_ <- eta_init

  } else if (parameterization == "multi_group") {
    sort_obj <- sort_neighborhoods(net_list, mod_names)
    net_list <- sort_obj$net_list
    mod_names <- sort_obj$mod_names
    dim_obj <- dim_fun(length(net_list), num_group, length(eta_init))
    dims <- dim_obj$dims
    labels <- assign_labels(length(net_list), dim_obj$sizes)
    eta_init_ <- c(eta_init, rep(rep(0, length(eta_init)), num_group - 1))

  } else if (parameterization == "size") {
    dims <- rep_row(rbind(seq(1, model_size)), length(net_list))
    eta_init_ <- eta_init
  }

  # Initialize object

  obj <- initialize_object(net_list = net_list,
                           model = model,
                           eta_init = eta_init_,
                           model_size = model_size,
                           etamap = eta_map,
                           sim_param = controls$sim_param,
                           est_param = controls$est_param,
                           dims = dims)
  
  # Create seeds if specified for simulation  
  if (!is.null(seeds)) { 
    run_seeds <- runif(obj$est$MCMLE_max_iter, 1000000, 9999999)
    obj$est$run_seeds <- run_seeds
    obj$est$seed_flag <- TRUE
  } else {
    obj$est$seed_flag <- FALSE
  } 

  obj$verbose <- verbose
  obj$est$parameterization <- parameterization
  
  # Call MCMLE to perform estimation
  obj <- MCMLE(obj)
  if (verbose > 0 & !obj$est$ML_status_fail) {
    eta_val <- obj$est$eta
    print_1 <- formatC(eta_val,
                       digits = 4,
                       format = "f")
    cat("\n         - estimate: ")
    cat(print_1, " ")

    score_val <- obj$est$score_val
    print_2 <- score_val
    print_2[score_val < 0.000001] <- "<.000001"
    print_2[score_val >= 0.000001] <- formatC(score_val[score_val >= 0.000001],
                                              digits = 4,
                                              format = "f")
    cat("\n         - score function at estimate: ")
    cat(print_2, " ")
    cat("\n")

    #if (obj$est$inCH_counter == 0) { 
    #  cat("\n\nWarning: Maximum number of iterations reached without the observation lying in the")
    #  cat(" interior of the simulated convex hull. Parameters not estimated.\n")
    #  obj$est$ML_status_fail <- TRUE
    #}
  } else if (verbose > 0 & obj$est$ML_status_fail) {

  }

  # Make structure to be returned
  if (!obj$est$ML_status_fail) {
    if (num_group > 1) {
      estimates <- make_return_obj(obj, labels, sort_obj$sort_order)
      estimates$estimation_method <- "MCMLE"
      estimates$estimation_stats <- "success"
    } else if (obj$est$inCH_counter > 0) {
      estimates <- list(estimates = obj$est$eta,
                        se = sqrt(diag(solve(obj$est$info_mat))),
                        estimation_method = "MCMLE",
                        estimation_status = "success")
    } else if (obj$est$inCH_counter == 0) { 
      # cat("\n\nWarning: Maximum number of iterations reached without the observation lying in the")
      # cat(" interior of the simulated convex hull. Parameters not estimated.\n")
      estimates <- list(estimates = obj$est$eta,
                        se = sqrt(diag(solve(obj$est$info_mat))),
                        estimation_method = "stepping",
                        estimation_status = "failed")
    }
  } else {
    estimates <- list(estimates = eta_init, #obj$est$eta_fun(obj$est$eta_0),
                      se = initial_se,  #rep(NA, length(obj$est$eta_fun(obj$est$eta_0))),
                      estimation_method = "MPLE",
                      estimation_status = "failed")
  }

  return(estimates)
}
