

step_to_chull <- function(obj) { 
  
  obj$net$obs_stats_step <- obj$net$obs_stats
  obj$est$gamma <- 1
  if (obj$verbose > 1) { 
    cat("\n\n")
  }

  sim_mat <- Reduce("+", obj$sim$stats)
  if (!is.inCH(obj$net$obs_stats_step, Reduce("+", obj$sim$stats))) { 
    step_flag <- TRUE
    iter <- 1
    sim_mean <- apply(Reduce("+", obj$sim$stats), 2, mean)
    if (obj$verbose > 0) {
      if (obj$verbose == 1) { 
        cat("\n\n")
      } 
      cat("  Observed sufficient statistic vector is not in the interior of the simulated convex hull.")
      obj$est$in_chull <- FALSE
      obj$est$adj_NR_tol <- 0.0001
    }
  } else {
    if (obj$verbose > 1) { 
      cat("  Observed sufficient statistic vector is in the interior of the simulated convex hull.")
      obj$est$in_chull <- TRUE
      obj$est$adj_NR_tol <- obj$est$NR_tol
    } 
    step_flag <- FALSE
  }

  adjust_flag <- FALSE
  max_grid_flag <- FALSE
  zero_flag <- FALSE
  step_grid <- seq(1, 0.000001, length.out = 200)
  while (!is.inCH(obj$net$obs_stats_step, sim_mat) & !adjust_flag & !zero_flag) {
    
    if (iter > 200) { 
      obj$est$gamma <- exp(- iter / 4)
      max_grid_flag <- TRUE
    }
    
    if (obj$verbose > 1 & iter == 1) { 
      cat("\n  Stepping towards observed sufficient statistics vector.")
    } 

    if (!max_grid_flag) { 
      obj$est$gamma <- step_grid[iter]
    }
    
    if (obj$verbose > 1) { 
      if (obj$est$gamma == 0) { 
        cat("\n\nWARNING: gamma = 0 required to move observation into the convex hull.")
        zero_flag <- TRUE
      }
    }
     
    obj$net$obs_stats_step <- obj$net$obs_stats * 1.05 * obj$est$gamma + (1 - 1.05 * obj$est$gamma) * sim_mean 
    iter <- iter + 1
  }
  if (!is.inCH(obj$net$obs_stats_step, sim_mat) & !adjust_flag) { 
    obj$net$obs_stats_step <- obj$net$obs_stats * obj$est$gamma + (1 - obj$est$gamma) * sim_mean
  }

  if (obj$verbose > 0) {
    if (step_flag) {
      cat("\n")
      cat("\n  Using adjusted observed sufficient statistics vector with gamma = ")
      cat(obj$est$gamma)
      cat(". L1 norm of difference: ")
      L1_diff <- sum(abs(obj$net$obs_stats_step - obj$net$obs_stats))
      if (round(L1_diff, digits = 3) < 0.001) { 
        cat("<0.001")
      } else { 
        cat(round(L1_diff, digits = 3))
      }
    } else { 
      #cat("\nUsing observed statistics vector.")
      #cat(paste(round(obj$net$obs_stats_step, digits = 3), collapse = ", "))
    }
  }
  return(obj)
}
