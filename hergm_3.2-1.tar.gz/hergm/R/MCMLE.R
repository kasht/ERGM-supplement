
MCMLE <- function(obj) {

  # Run the estimation procedure until termination criterions are met
  conv_flag_1 <- FALSE
  conv_flag_2 <- FALSE
  obj$est$inCH_counter <- 0
  while (!obj$est$MCMLE_status & (obj$est$MCMLE_iter <= obj$est$MCMLE_max_iter) & !obj$est$ML_status_fail) {

    # Get MCMC sample
    if (obj$verbose > 0) { 
      cat("\n\nStep 3.1 Sampling networks")
    } 
    if (obj$est$par_flag) {
      obj <- MCMC_sample_par(obj)
    } else {
      obj <- MCMC_sample(obj)
    }
    
    # Check that the distribution is not degenerate
    degen_flag <- FALSE 
    sd_ <- lapply(obj$sim$stats, function(x) { apply(x, 2, sd) })
    sd_check <- matrix(0, nrow = obj$net$num_clust, ncol = obj$net$num_terms)
    for (i in 1:obj$net$num_clust) { 
      sd_check[i, ] <- sd_[[i]]
    }
    sd_check_sum <- colSums(sd_check)
    if (sum(sd_check_sum == 0) > 0) { 
      cat("\nWARNING: Standard deviation of some simulated statistics are zero. Proposed model may be")
      cat(" degenerate.\n\n")
      degen_flag <- TRUE
    }
    #sim_stats <- Reduce("+", obj$sim$stats)
    
    #if (sum(duplicated(sim_stats)) == (nrow(sim_stats) - 1)) { 
    #  degen_flag <- TRUE
    #  cat("\nWARNING: Simulated statistics are all equal. Proposed model may be degenerate.\n\n")
    #}
    if (!degen_flag) { 
      # Use stepping algorithm to put observed vector within the convex hull of the sim sufficient statistics 
      obj <- step_to_chull(obj)

      if (obj$est$gamma == 1) { 
        obj$est$inCH_counter <- obj$est$inCH_counter + 1
      }
  
      # Optimize log-likelihood approximation
      if (obj$verbose > 0) { 
        cat("\n\nStep 3.2 Estimating parameters:")
      }
      obj <- opt_fisher(obj)
  
      # If two consecutive samples have been within the convex hull, accept convergence 
      if (obj$est$inCH_counter == 2) { 
        obj$est$MCMLE_status <- TRUE
      }
   
      if (obj$est$inCH_counter < 2) { 
        obj$est$MCMLE_iter <- obj$est$MCMLE_iter + 1
      }
  
      if (!obj$est$MCMLE_status & (obj$est$MCMLE_iter <= obj$est$MCMLE_max_iter) & !obj$est$ML_status_fail) { 
        if (obj$verbose > 0) { 
          cat("\n         - estimate: ")
          cat(formatC(obj$est$eta, digits = 4, format = "f"))
          
          score_val <- obj$est$score_val
          print_1 <- score_val 
          print_1[score_val < 0.000001] <- "<.000001"
          print_1[score_val >= 0.000001] <- formatC(score_val[score_val >= 0.000001], digits = 6, format = "f")
          cat("\n         - score function at estimate: ", print_1)
        }
      } else if (obj$est$ML_status_fail) { 
      } 
    } else { 
      obj$est$ML_status_fail <- TRUE  
    }
  }
  return(obj)
}



