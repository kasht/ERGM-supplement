find_phi_coefficient <- function (z_memb, true_memb) {
  n <- length(z_memb)
  if (n < 2000) {
    true_matrix <- matrix(0, n, n)
    est_matrix <- true_matrix
    for (i in unique(z_memb)) {
      est_matrix[z_memb == i, z_memb == i] <- 2
    }
    for (i in unique(true_memb)) {
      true_matrix[true_memb == i, true_memb == i] <- 1
    }
    diag(true_matrix) <- diag(est_matrix) <- 0
    res_matrix <- true_matrix - est_matrix
    n_00 <- as.numeric(sum(res_matrix == 0))
    n_01 <- as.numeric(sum(res_matrix == 1))
    n_10 <- as.numeric(sum(res_matrix == -2))
    n_11 <- as.numeric(sum(res_matrix == -1))
  } else {
    n_00 <- n_01 <- n_10 <- n_11 <- 0
    n_blocks <- (n%/%1000)
    if (n%%1000 == 0) {
      sizes <- c(rep(1000, n_blocks))
    } else {
      sizes <- c(rep(1000, n_blocks - 1), n - 1000 * n_blocks)
    }
    cum_sizes <- c(0, cumsum(sizes))
    for (i in 1:n_blocks) {
      for (j in i:n_blocks) {
        temp_matrix_full_true <- matrix(0, sizes[i], 
                                        sizes[j])
        temp_matrix_full_est <- matrix(0, sizes[i], sizes[j])
        for (k in unique(z_memb)) {
          temp_matrix_full_est[z_memb[(cum_sizes[i] + 
                                         1):(cum_sizes[i + 1])] == k, z_memb[(cum_sizes[j] + 
                                                                                1):(cum_sizes[j + 1])] == k] <- 2
        }
        for (k in unique(true_memb)) {
          temp_matrix_full_true[true_memb[(cum_sizes[i] + 
                                             1):(cum_sizes[i + 1])] == k, true_memb[(cum_sizes[j] + 
                                                                                       1):(cum_sizes[j + 1])] == k] <- 1
        }
        diag(temp_matrix_full_true) <- diag(temp_matrix_full_est) <- 0
        res_matrix <- temp_matrix_full_true - temp_matrix_full_est
        n_temp_01 <- as.numeric(sum(res_matrix == 1))
        n_temp_10 <- as.numeric(sum(res_matrix == -2))
        n_temp_11 <- as.numeric(sum(res_matrix == -1))
        n_temp_00 <- sizes[i] * sizes[j] - (n_temp_01 + 
                                              n_temp_10 + n_temp_11)
        n_00 <- n_00 + n_temp_00 * ((i != j) + 1)
        n_01 <- n_01 + n_temp_01 * ((i != j) + 1)
        n_10 <- n_10 + n_temp_10 * ((i != j) + 1)
        n_11 <- n_11 + n_temp_11 * ((i != j) + 1)
      }
    }
  }
  n_00 <- n_00 - n
  n_1_dot <- n_11 + n_10
  n_0_dot <- n_01 + n_00
  n_dot_1 <- n_11 + n_01
  n_dot_0 <- n_10 + n_00
  first_product <- (n_11/sqrt(n_1_dot)/sqrt(n_0_dot)) * (n_00/sqrt(n_dot_1)/sqrt(n_dot_0))
  second_product <- (n_10/sqrt(n_1_dot)/sqrt(n_0_dot)) * (n_01/sqrt(n_dot_1)/sqrt(n_dot_0))
  phi_coef <- first_product - second_product
  phi_coef
}


plot_neighborhoods <- function(network, partition) {
  plot(
    as.network(network),
    vertex.col = partition,
    edge.col = same_clusters(partition),
    main = ""
  )
}

permute_tau <- function(tau, labels) {
  new_tau <- tau
  for (i in 1:length(labels)) {
    #temp[z_memb == i] <- labels[as.numeric(names(labels))==i]
    new_tau[, i] <- tau[, labels[i]]
  }
  new_tau
}

logit <- function(x)
  qlogis(x)
inv.logit <- function(x)
  exp(x) / (1 + exp(x))

#Spectral clustering
spec_clust <- function(network, max_number) {
  network <- as.matrix(network)
  n <- nrow(network)
  n_vec = ceiling(sqrt(n))
  b <- eigen(network, symmetric = TRUE)$vectors[, 1:n_vec]
  c <- kmeans(
    b,
    centers = max_number,
    nstart = 100,
    iter.max = 20,
    algorithm = "Hartigan-Wong"
  )
  c.ind <- c$cluster
  z_memb <- factor(c.ind, levels = 1:max_number)
  z_memb
}

#Finish this function, need to get rid of empty clusters.
check_clusters <-
  function(z_memb, network, max_number, min_size = 3) {
    n <- nrow(network)
    n_vec = ceiling(sqrt(n))
    b <- eigen(network, symmetric = TRUE)$vectors[, 1:n_vec]
    z_memb <- factor(z_memb, levels = 1:max_number)
    repeat {
      z_memb_temp <- as.vector(z_memb)
      z_memb <- factor(z_memb_temp, levels = 1:max_number)
      bad_clusters <- which(table(z_memb) < min_size)
      if (length(bad_clusters) == 0)
        break

      bad_cluster <- which(table(z_memb) < 2)[1]
      donor <- which.max(table(z_memb))
      indeces <- c(bad_clusters, donor)
      temp <-
        kmeans(
          b[z_memb %in% indeces,],
          centers = 2,
          nstart = 100,
          iter.max = 20,
          algorithm = "Hartigan-Wong"
        )
      for (i in 1:length(indeces)) {
        z_memb_temp[z_memb %in% indeces][temp$cluster == i] <- indeces[i]
      }
      z_memb <- factor(z_memb_temp, levels = 1:max_number)
    }
    z_memb
  }

#Simulate hergm
simulate_hergm <- function(formula, coef_w, coef_b, z_memb, parameterization = "standard",
                           directed = TRUE, matrix_sbm = NULL)
{
  #Initialization
  n_nodes <- length(z_memb)
  block_sizes <- table(z_memb)
  memb_inds <- as.numeric(names(block_sizes))

  #Parse formula
  rhs <- paste(deparse(formula[[3]]), collapse = "")
  lhs <- paste(deparse(formula[[2]]), collapse = "")

  #mode = 0 simulating from scratch
  #mode = 1 if formula contains a network
  mode = 0
  if (exists(lhs)) {
    temp <- get0(lhs)
    if (is.network(temp)){
      mode <- 1
    }
  }
  #we assume coef_b always has log n parameterization
  coef_b <- coef_b * log(n_nodes)
  if (is.null(matrix_sbm)) {
    network <- matrix(rbinom(n_nodes^2, 1, inv.logit(coef_b)), n_nodes, n_nodes)
  } else {
    network <- apply(matrix_sbm, c(1,2), function(x) rbinom(1,1,inv.logit(x)))
  }
  if (directed == FALSE) {
    network[lower.tri(network)] <- t(network)[lower.tri(network)]
  }

  if (mode == 0) {
  #Fill in within neighborhood parts
  for (i in memb_inds) {
    n_nodes_in_block = sum(z_memb == i)
    if (directed == TRUE) {
      lhs <- paste("network(", n_nodes_in_block, ")", sep = "")
    } else {
      lhs <- paste("network(", n_nodes_in_block, ", directed = FALSE)", sep = "")
    }
    form <- as.formula(paste(lhs, "~", rhs))
    if (parameterization == "size") {
      temp_network = simulate(form, coef = coef_w*log(n_nodes_in_block))
    } else {
      temp_network = simulate(form, coef = coef_w)
      }
    network[z_memb == i, z_memb == i] <- as.matrix(temp_network)
  }
  } else {
    for (i in memb_inds) {
      n_nodes_in_block = sum(z_memb == i)
      v_id <- which(z_memb == i)
      subgraph_temp <- get.inducedSubgraph(temp, v = v_id)
      lhs_sub <- "subgraph_temp"
      form <- as.formula(paste(lhs_sub, "~", rhs))
      if (parameterization == "size") {
        temp_network = simulate(form, coef = coef_w*log(n_nodes_in_block))
      } else {
        temp_network = simulate(form, coef = coef_w)
      }
      network[z_memb == i, z_memb == i] <- as.matrix(temp_network)
    }
  }
  as.network(network, directed = directed)
}

#Initial estimate of parameters
init_estimate_params <- function(formula,
           network,
           z_memb,
           parameterization,
           method = "MPLE")
  {

    directed_ <- network::is.directed(network)
    # Check for edge covariates
    if (sum(grepl("edgecov", formula) | grepl("dyadcov", formula)) > 0) {
      term_vec <- strsplit(as.character(formula), " ")[[3]]
      where_ <- grepl("edgecov", term_vec) | grepl("dyadcov", term_vec)
      #edge_cov_name  <- strsplit(term_vec[where_], "\"")[[1]][2]

      #Names of multiple covariates
      edge_cov_name  <- lapply(term_vec[where_], function(x) strsplit(x, "\"")[[1]][2])

      #Covariates corresponding to edge_cov_name
      edge_cov <- lapply(edge_cov_name,
                         function(x) Matrix(get.network.attribute(network,x) , sparse = TRUE))
      edge_cov_list <- rep(list(NULL), length(unique(z_memb)))

      #List of lists of covariate sub-networks
      for (i in sort(as.numeric(unique(z_memb)))) {
        edge_cov_list[[i]] <- lapply(edge_cov, function(x) x[z_memb == i, z_memb == i])
      }
    }

    #Initialization
    network_mat <- as.matrix(network)
    n_nodes <- length(z_memb)
    block_sizes <- table(z_memb)
    memb_inds <- as.numeric(names(block_sizes))
    max_number = length(block_sizes)

    #Parse formula and find number of right hand side terms
    rhs <- paste(deparse(formula[[3]]), collapse = "")
    rhs.terms <- strsplit(rhs, "\\s*(\\+|\\*)\\s*")[[1]]
    n_terms <- length(rhs.terms)
    if (sum(grepl("_ijk", rhs.terms)) > 0 | sum(grepl("_ij", rhs.terms)) > 0) {
      rhs.terms <- unlist(check_extensions(rhs.terms))
      rhs <- paste(rhs.terms, collapse = " + ")
    }
    lhs = "network_temp_"
    form = as.formula(paste(lhs, "~", rhs))
    counter <- 0
    params <- matrix(0, max_number, n_terms)
    params_density <- matrix(0, max_number, n_terms)
    #oldw <- getOption("warn")
    #options(warn = -1)

    #Diagnostic check for sub-network degeneracy
    options(warn = 1)
    degenerate_neighborhood <- numeric(max_number)
    for (i in memb_inds) {
      one_node_cluster <- FALSE
      counter <- counter + 1
      network_temp <- as.matrix(network_mat[z_memb == i, z_memb == i])
      if (block_sizes[i] > 1){
        density <- sum(network_temp) /
          (block_sizes[i] * (block_sizes[i] - 1))
      } else
      {
        one_node_cluster <- TRUE
      }
      degenerate_neighborhood[counter] <-
        (one_node_cluster | density == 0 | density == 1)
    }
    rate_of_degenerate <- sum(degenerate_neighborhood)/length(degenerate_neighborhood)

    if (rate_of_degenerate == 1)
      stop ("WARNING: All estimated neighborhoods are either degenerate or isolates")

    if (rate_of_degenerate > 0.5)
      warnings ("WARNING: Some estimated neighborhoods are either degenerate or isolates.\nParameter estimation is unreliable")
    counter <- 0
    for (i in memb_inds) {
      one_node_cluster <- FALSE
      counter <- counter + 1
      v_id <- which(z_memb == i)
      network_temp <- as.matrix(network_mat[z_memb == i, z_memb == i])
      network_temp_ <- get.inducedSubgraph(network, v = v_id)
      if (sum(grepl("edgecov", formula) | grepl("dyadcov", formula)) > 0) {
        for (q in 1:length(edge_cov_name))
        set.network.attribute(network_temp_, edge_cov_name[[q]], as.matrix(edge_cov_list[[i]][[q]]))
      }
      if (block_sizes[i] > 1){
        density <- sum(network_temp) /
          (block_sizes[i] * (block_sizes[i] - 1))
      } else
      {
        one_node_cluster <- TRUE
        density = 1
      }

      if (density == 0 || density == 1) {
        edge_coef <- NA
      } else {
        edge_coef <- logit(density) / log(nrow(network_temp))
      }


      #Find stats, target stats?
      if (density != 1 && density != 0) {
        suppressWarnings(invisible(capture.output(if (parameterization == "size") {
          param_est <-
            ergm(form, estimate =  method)$coef / log(nrow(network_temp))
        } else {
          param_est <- ergm(form, estimate = method)$coef
        })))
        params[counter,] <- param_est
      } else {
        params[counter,] <- rep(NA,n_terms)
      }

      if (!one_node_cluster) {
        params_density[counter,] <- c(edge_coef, rep(0, n_terms - 1))
      } else {
        params_density[counter,] <- rep(NA, n_terms)
      }
    }
    #options(warn = oldw)
    #Get rid of unreasonable estimates corresponding to MPLE glm.fit failure
    params <- params[apply(params, 1, function(x)
      sum(abs(x))) < 10,]

    if (nrow(as.matrix(params)) > 1) {
      output <- apply(params, 2, function(x)
        mean(x, na.rm = TRUE))
    } else {
      output <- apply(params_density, 2, function(x)
        mean(x, na.rm = TRUE))
    }
    output
  }

estimate_params_jonathan <-
  function(formula,
           network,
           parameterization,
           z_memb,
           parallel = FALSE,
           number_cores = 3,
           max_iter = 5,
           number_groups = 1,
           verbose = 1,
           initial_estimate = NULL,
           MCMCparams,
           seeds)
  {
    n_nodes <- length(z_memb)
    block_sizes <- table(z_memb)
    memb_inds <- as.numeric(names(block_sizes))
    max_number = length(block_sizes)
    mod_names <- rep(list(NULL), max_number)
    rhs <- paste(deparse(formula[[3]]), collapse = "")
    rhs.terms <- strsplit(rhs, "\\s*(\\+|\\*)\\s*")[[1]]

    if (sum(grepl("edgecov", formula) | grepl("dyadcov", formula)) > 0) {
      term_vec <- strsplit(as.character(formula), " ")[[3]]
      where_ <- grepl("edgecov", term_vec) | grepl("dyadcov", term_vec)
      edge_cov_name  <- lapply(term_vec[where_], function(x) strsplit(x, "\"")[[1]][2])
      edge_cov <- lapply(edge_cov_name,
                         function(x) Matrix(get.network.attribute(network,x) , sparse = TRUE))
      edge_cov_list <- rep(list(NULL), max_number)
      for (i in sort(as.numeric(unique(z_memb)))) {
        edge_cov_list[[i]] <- lapply(edge_cov, function(x) x[z_memb == i, z_memb == i])
      }
      for (k in 1:length(edge_cov_name)) {
        delete.network.attribute(network, edge_cov_name[[k]])
      }
    }

    for (k in 1:max_number) {
      mod_names[[k]] <- rhs.terms
    }
    net_list <- rep(list(NULL), max_number)
    for (k in 1:max_number) {
      if (sum(z_memb == memb_inds[k]) > 1) {
        v_id <- which(z_memb == memb_inds[k])
        net_list[[k]] <- get.inducedSubgraph(network, v = v_id)
        if (sum(grepl("edgecov", formula) | grepl("dyadcov", formula)) > 0) {
          for (ii in 1:length(edge_cov_name)) {
            set.network.attribute(net_list[[k]], edge_cov_name[[ii]], as.matrix(edge_cov_list[[k]][[ii]]))
          }
        }
      } else {
        net_list[[k]] <- network.initialize(1)
        if (sum(grepl("edgecov", formula) | grepl("dyadcov", formula)) > 0) {
          set.network.attribute(net_list[[k]], edge_cov_name, as.matrix(edge_cov_list[[k]]))
        }
      }
    }
    
    # Check that no subgraph is complete or empty
    comp_sub <- numeric(length(net_list))
    emp_sub <- numeric(length(net_list))
    for (i in 1:length(net_list)) {
      n_ <- net_list[[i]]$gal$n
      directed_ <- is.directed(net_list[[i]])
      if (directed_) {
        sum_ <- summary(net_list[[i]] ~ edges)
        comp_sub [i] <- (sum_ == (n_ * (n_ - 1)))  
        emp_sub[i] <- (sum_ == 0)
      } else {
        sum_ <- summary(net_list[[i]] ~ edges)
        comp_sub[i] <- (sum_ == choose(n_, 2)) 
        emp_sub[i] <- (sum_ == 0)
      }
    }
    
    if (sum(comp_sub) == length(net_list)) { 
      extreme_flag <- TRUE
    
    } else if (sum(emp_sub) == length(net_list)) { 
      extreme_flag <- TRUE
    
    } else { 
      extreme_flag <- FALSE
    }
   
    # Remove neighborhoods with only one node 
    net_list_ <- rep(list(NULL), sum(comp_sub == 0))
    iter <- 1
    for (i in 1:length(net_list)) {
      if ((net_list[[i]]$gal$n > 1)) {
        net_list_[[iter]] <- net_list[[i]]
        iter <- iter + 1
      }
    }
    rm(net_list)
    
    
    if (extreme_flag) {
      complete_graph_flag <- TRUE
      cat("\n\nWARNING: All estimated or specified neighborhoods are either all complete or all empty.\n")
    } else {
      complete_graph_flag <- FALSE
    }

    # call initialization procedure and pass network list
    initial_specified_flag <- !is.null(initial_estimate)
    if (initial_specified_flag) { 
      init_params <- list(init_param = initial_estimate, init_se = NULL)
    }

    if (!complete_graph_flag) {

      if (!is.curved(formula) & !initial_specified_flag) {
        init_params <- compute_initial_parameters(list(net_list = net_list_,
                                                       mod_names = mod_names,
                                                       parameterization = parameterization,
                                                       estimate = "MPLE"))
      } else if (is.curved(formula) & !initial_specified_flag) {
        init_params <- compute_initial_parameters_curved(list(net_list = net_list_,
                                                              form = formula,
                                                              mod_names = mod_names,
                                                              parameterization = parameterization,
                                                              estimate = "CD"))
      }

      if (verbose == 2) {cat(paste("\n\n Initial parameter estimate: ",
                                   paste(round(init_params$init_param, digits = 4), collapse=", "),sep=""))}

      params <- est_ergm(
        net_list_,
        formula,
        #mod_names,
        init_params,
        controls = est_control(
          burnin = MCMCparams$burnin,
          interval = MCMCparams$interval,
          num_obs = MCMCparams$samplesize,
          NR_max_iter = 200,
          MCMLE_max_iter = max_iter,
          par_comp = parallel,
          par_n_cores = number_cores
        ),
        num_group = number_groups,
        parameterization = parameterization,
        verbose = verbose,
        seeds = seeds
      )
    } else {
      params <- list(estimates = NA, se = NA, estimation_method = "Not estimated", estimation_status = "failed")
    }
    params
  }


#Estimate between-neighborhood parameter
estimate_bw_param <- function(network, z_memb) {
  n_nodes <- length(z_memb)
  block_sizes <- table(z_memb)
  memb_inds <- as.numeric(names(block_sizes))
  max_number = length(block_sizes)

  indicator = matrix(TRUE, n_nodes, n_nodes)
  for (i in memb_inds)
  {
    indicator[z_memb == i, z_memb == i] <- FALSE
  }
  n <- sum(indicator)
  k <- sum(network[indicator])
  bw_param = logit(k / n)/log(n_nodes)
  bw_st_error = ((1 / k) + (1 / (n - k)))/log(n_nodes)
  list(bw_param = bw_param,
       bw_st_error = bw_st_error)
}

same_clusters <- function(z_memb) {
  n_nodes <- length(z_memb)
  block_sizes <- table(z_memb)
  memb_inds <- as.numeric(names(block_sizes))
  indicator = matrix('grey', n_nodes, n_nodes)
  for (i in memb_inds)
  {
    indicator[z_memb == i, z_memb == i] <- 'black'
  }
  indicator
}

#Estimate deinsity inside clusters
estimate_density <- function(network, z_memb, bw_param) {
  n_nodes <- length(z_memb)
  block_sizes <- table(z_memb)
  memb_inds <- as.numeric(names(block_sizes))
  max_number = length(block_sizes)

  Pi = matrix(inv.logit(bw_param), max_number, max_number)
  for (i in 1:max_number) {
    Pi[i, i] = sum(network[z_memb == memb_inds[i], z_memb == memb_inds[i]]) /
      (block_sizes[i] * (block_sizes[i] - 1))
  }
  Pi
}

#Need to add split cluster function and restart
EM_wrapper_fast <-
  function(network,
           formula,
           max_number,
           n_em_step_max = 100,
           min_size = 2,
           start_alg = c("SpecClust", "WalkTrap"),
           verbose = 1)
  {
    #Step 0: Initialization

    n_nodes <- nrow(as.matrix(network))
    ## Calculate network statistics needed for variational approximation of p(Z|X)
    if (verbose > 0) cat("\nStep 1: Initialize z")
    stat00 <-
      stat01 <-
      stat10 <- stat11 <- matrix(as.integer(0), n_nodes, n_nodes)

    stats <- calculateStats(network, stat00, stat01, stat10, stat11)
    stat00 <- matrix(as.double(stats[[1]]), n_nodes, n_nodes)
    stat01 <- matrix(as.double(stats[[2]]), n_nodes, n_nodes)
    stat10 <- matrix(as.double(stats[[3]]), n_nodes, n_nodes)
    stat11 <- matrix(as.double(stats[[4]]), n_nodes, n_nodes)

    #Step 1a: Get initial estimate of Z memberships using spectral clustering
    # if(verbose > 0) cat("\n\nStep 1b: Initialize Z using spectral clustering or walktrap method.")
    start_alg = start_alg[1]
    if (start_alg == "SpecClust") {
      z_memb <- spec_clust(network, max_number)
      z_memb_init <- z_memb
    } else
    {
      g <- asIgraph(as.network(network))
      b <- cluster_walktrap(g, steps = 4)
      temp_ind <- factor(b$membership, levels = 1:max_number)
      z_memb_init <- temp_ind
      z_memb <-
        factor(check_clusters(temp_ind, network, max_number, min_size),
               levels = 1:max_number)
    }

    #Step 1b: Get estimate of ERGM parameters within clusters
    # if(verbose > 0) cat("\n\nStep 1c: Compute estimate of density within clusters")
    bw_param <- estimate_bw_param(network, z_memb)$bw_param
    Pi = estimate_density(network, z_memb, bw_param)

    #Step 2a: Find A(Z=z) ~ P(Z=z|X=x)
    if (verbose > 0)
      {
      cat(paste("\n\nStep 2: Find variational approximation A(Z=z) ~ P(Z=z|X=x)", sep = ""))
      }
    block_sizes <- table(z_memb)
    memb_inds <- as.numeric(names(block_sizes))
    max_number = length(block_sizes)

    tau <- matrix(0, n_nodes, max_number)
    tau_prev <- matrix(0, n_nodes, max_number)
    for (i in 1:n_nodes) {
      tau[i,] <- 1
      tau[i, z_memb[i]] <- 1000
      tau[i,] <- tau[i,] / sum(tau[i,])
    }
    alpha = colMeans(tau)

    delta <- row(Pi) - col(Pi)
    counter_e_step <- 0
    repeat {
      counter_e_step <- counter_e_step + 1
      tau_prev <- tau
      tau <-
        runFixedPointEstimationEStepMM(
          as.integer(n_nodes),
          as.integer(max_number),
          as.double(alpha),
          Pi,
          stat00,
          stat01,
          stat10,
          stat11,
          tau,
          network
        )

      Pi <- easy_M_Step(
        as.integer(n_nodes),
        as.integer(max_number),
        as.double(alpha),
        Pi,
        as.matrix(network),
        tau
      )

      #if (!isTauSignificantlyChanged(10^-10, tau, tau_prev)) break
      
      #Make all off-diagonal elements equal
      #Pi[delta != 0] <- mean(Pi[delta != 0])

      #Permute labels
      perm <- sample(1:max_number)
      tau <- permute_tau(tau, perm)
      Pi <- Pi[perm, perm]


      alpha = colMeans(tau)
      if(counter_e_step %% 5) gc()
      if (counter_e_step >=  n_em_step_max) {
        break
      }
    }

    z_memb <-
      factor(apply(tau, 1, which.max), levels = 1:max_number)
    z_memb_final <-
      factor(check_clusters(z_memb, network, max_number, min_size),
             levels = 1:max_number)

    list(
      #tau = tau,
      Pi = Pi,
      z_memb_init = z_memb_init,
      z_memb_em = z_memb,
      z_memb_final = z_memb_final
    )
  }

hergm.large <- function(network,
           formula,
           parameterization,
           max_number,
           number_cores,
           number_groups = 1,
           indicator = NULL,
           same_between_blocks = TRUE,
           estimate_parameters = TRUE,
           verbose,
           n_em_step_max = 100,
           max_iter = max_iter, 
           initial_estimate = NULL,
           MCMCparams,
           seeds = NULL)
  {
    if (number_cores == 1)
    {
      parallel <- FALSE
    }
    else
    {
      parallel = TRUE
    }
    network_ <- network
    network <- as.matrix(network)
    sbm_pi <- NULL
    if (is.null(indicator)) all_indicators_fixed <- FALSE
    else all_indicators_fixed <- TRUE
    if (all_indicators_fixed == FALSE)
      {
      answer <- EM_wrapper_fast(
      network,
      formula,
      max_number,
      n_em_step_max = n_em_step_max,
      min_size = 1,
      start_alg = "SpecClust",
      verbose = verbose
      )
      indicator = answer$z_memb_final
      sbm_pi <- answer$Pi
      }
    else cat("\nSkipping Step 1 and 2: z specified")

    if (estimate_parameters == TRUE)
      {
      #med_params <- init_estimate_params(formula, network_, indicator, parameterization = parameterization)
      if (verbose > 0)
        {
        cat("\n\nStep 3: Estimate parameters conditional on z")
        }

      params <-  estimate_params_jonathan(
        formula,
        network_,
        parameterization,
        indicator,
        initial_estimate = initial_estimate,
        parallel = parallel,
        number_cores = number_cores,
        max_iter = max_iter,
        number_groups = number_groups,
        verbose = verbose,
        MCMCparams = MCMCparams,
        seeds = seeds
        )
      estimation_status <- params$estimation_status
      if (number_groups == 1) {
        parameters = t(as.matrix(params$estimates))
        st.error = params$se
        labels = 1:max_number
      } else {
        st.error <- parameters <- labels <- list()
        for (i in 1:number_groups) {
        parameters[[i]] <- params[[i]]$estimates
        st.error[[i]] <- params[[i]]$se
        labels[[i]] <- params[[i]]$labels
        }
      }

    between_parameter <- list()
    st.error.between <- list()
    if (same_between_blocks){
      bw_params <- estimate_bw_param(network, indicator)
      between_parameter <- bw_params$bw_param
      st.error.between <- bw_params$bw_st_error
    } else {
      n_nodes <- length(indicator)
      between_parameter <- matrix(NA, max_number, max_number)
      st.error.between <- matrix(NA, max_number, max_number)
      block_sizes <- table(indicator)
      memb_inds <- as.numeric(names(block_sizes))
      for (i in 1:(max_number-1)){
        for (j in (i+1):max_number){
          n <- block_sizes[i]*block_sizes[j]
          k <- sum(network[indicator == i, indicator == j])
          if (parameterization == "size"){
          between_parameter[i,j] <- between_parameter[j,i] <- logit(k / n) / log(n_nodes)
          st.error.between[i,j] <- st.error.between[j,i] <-
                                  ((1 / k) + (1 / (n - k)))/ log(n_nodes)
          } else {
            between_parameter[i,j] <- between_parameter[j,i] <- logit(k / n)
            st.error.between[i,j] <- st.error.between[j,i] <-
              ((1 / k) + (1 / (n - k)))
          }
        }
      }
    }
    }
   else # estimate_parameters = FALSE:
     {
     cat("\n")
     estimation_status <- "not_estimated"
     parameters <- NULL
     st.error <- NULL
     between_parameter <- NULL
     st.error.between <- NULL
     }

    list(
      sbm.params = sbm_pi,
      partition = indicator,
      parameters = parameters,
      st.error = st.error,
      between_parameter = between_parameter,
      st.error.between = st.error.between,
      labels = labels,
      estimation_status = estimation_status
    )
  }

compute_initial_parameters <- function(obj) {
    n_terms <- length(obj$mod_names[[1]])
    coef_mat <- matrix(0, nrow = length(obj$net_list), ncol = n_terms)
    dens_vect <- numeric(length(obj$net_list))
    response <- predictors <- weights <- NULL
    for (i in 1:nrow(coef_mat)) {
      form <- paste("cur_net ~ ", paste(obj$mod_names[[i]], collapse = "+"))
      form <- as.formula(form)
      cur_net <- obj$net_list[[i]]
      density_ <- summary(cur_net ~ density)
      dens_vect[i] <- density_
      if (density_ != 1 && density_ != 0) {
        mplesetup <- ergmMPLE(form)
        mplesetup$weights <- mplesetup$weights/sum(mplesetup$weights)
        response <- c(response,mplesetup$response)
        predictors <- rbind(predictors,mplesetup$predictor)
        weights <- c(weights,mplesetup$weights)
      }
    }

    ## Remove bad initializations
    #bad_mat <- which(apply(coef_mat,1, function(x) sqrt(sum(x^2)/length(x))) > 4)
    #if (length(bad_mat) > 0) coef_mat <-  coef_mat[-bad_mat, ]

    # Compute initial estimate
    glm.result <- glm(response ~ . - 1, data = data.frame(predictors),
                      weights = weights, family="quasibinomial")
    a <- summary(glm.result)
    if (obj$parameterization == "size"){
    mean_size <- mean(unlist(lapply(obj$net_list, function(x) x$gal$n)))
    } else {
      mean_size <- exp(1)
    }
    return(list(init_param = glm.result$coefficients/log(mean_size),
                init_se = summary(glm.result)$coefficients[,2]/log(mean_size)))
}

compute_initial_parameters_curved <- function(obj) {
     estimate_ <- "CD"
     suff_sizes <- numeric(length(obj$net_list))
     for (i in 1:length(obj$net_list)) {
        cur_net <- obj$net_list[[i]]
        form_ <- as.formula(paste("cur_net ~ ", paste(deparse(obj$form[[3]]), collapse = "")))
        suff_sizes[i] <- length(summary(form_))
     }
     directed_ <- is.directed(obj$net_list[[1]])
     largest_ <- obj$net_list[[which.max(suff_sizes)]]
     form <- paste("largest_ ~ ", paste(obj$mod_names[[1]], collapse = "+"))
     form <- as.formula(form)
     model_ <- ergm.getmodel(form_, largest_)
     eta_map <- ergm.etamap(model_)
     suppressWarnings(invisible(capture.output(
       get_init_size <- length(eta_map$canonical)
     )))
     n_terms <- get_init_size
     num_clust <- length(obj$net_list)
     est_split <- split(1:num_clust, ceiling(seq_along(1:num_clust) / 3))
     coef_mat <- matrix(0, nrow = length(est_split), ncol = n_terms)
     se_mat <- coef_mat
     dens_vect <- numeric(length(nrow(coef_mat)))
     for (i in 1:nrow(coef_mat)) {
       form <- paste("cur_net ~ ", paste(obj$mod_names[[i]], collapse = "+"))
       form <- as.formula(form)
       cur_group <- est_split[[i]]
       cur_net <- matrix(0, nrow = 0, ncol = 0)
       for (mm in 1:length(cur_group)) { 
         cur_net <- as.matrix(bdiag(cur_net, obj$net_list[[cur_group[[mm]]]][ , ]))     
       }
       cur_net <- network(cur_net, directed = directed_)
       cur_est_group <- unlist(lapply(1:length(cur_group),
                                  function(x, net_list, cur_group) {
                                    rep(x, net_list[[cur_group[x]]]$gal$n)
                                  }, 
                                  net_list = obj$net_list, 
                                  cur_group = cur_group))
       set.vertex.attribute(cur_net, "cur_est_group", cur_est_group)
       density_ <- summary(cur_net ~ density, constraints = ~ blockdiag("cur_est_group"))
       dens_vect[i] <- density_
       param_est <- numeric(get_init_size)
       se_est <- numeric(get_init_size)
       if (density_ != 1 && density_ != 0) {
         suppressWarnings(invisible(capture.output(
           if (obj$parameterization == "size") {
             temp_cur_nte_mtx <- as.matrix(cur_net)
             res <- tryCatch({ ergm(form, estimate =  estimate_,
                             constraints = ~ blockdiag("cur_est_group")) },
                             error = function(e) { 
                                return("failed")
                             })

             if (res == "failed") {
               res <- ergm(cur_net ~ edges, constraints = ~ blockdiag("cur_est_group"))
               param_est[1] <- res$coef 
               se_est <- sqrt(diag(res$covar))
             } else { 
               param_est <- res$coef
               which_canonical <- which(eta_map$canonical != 0)
               param_est[which_canonical] <- res$coef[which_canonical] / log_fun(nrow(temp_cur_nte_mtx))
               which_curved <- which(eta_map$canonical == 0)
               for (ii in seq(1, length(which_curved), by = 2)) { 
                 param_est[which_curved[ii]] <- param_est[which_curved[ii]] / log_fun(nrow(temp_cur_nte_mtx))
               }
               se_est <- sqrt(diag(res$covar))
             }

           } else {
             res <- tryCatch({ ergm(form, estimate = obj$estimate,
                                    constraints = ~ blockdiag("cur_est_group")) },
                             error = function(e) { return("failed")
                             })
             if (res == "failed") { 
               res <- ergm(cur_net ~ edges, constraints = ~ blockdiag("cur_est_group"))
               param_est[1] <- res$coef
               se_est <- sqrt(diag(res$covar))
             } else { 
               param_est <- res$coef
               se_est <- sqrt(diag(res$covar))
             }
           })))
           
           
           coef_mat[i, ] <- as.numeric(param_est)
           se_mat[i, ] <- se_est
         } else {
           coef_mat[i, ] <- rep(100, n_terms)
           coef_mat[i, ] <- rep(100, n_terms)
         }
       }

     # Remove bad initializations
     mean_est <- colMeans(coef_mat)
     sd_est <- apply(coef_mat, 2, sd)
     bad_mat <- which(apply(coef_mat, 1, function(x, mean_est, sd_est) { 
                                              sum(abs(x - mean_est) > 3 * sd_est) > 0  
                                         },
                            mean_est = mean_est, sd_est = sd_est))
     if (length(bad_mat) > 0 & (length(bad_mat) != nrow(coef_mat))) {
       coef_mat <-  coef_mat[-bad_mat, ]
       se_mat <- se_mat[-bad_mat, ]
     }

     if (!is(coef_mat)[1] == "matrix") {
       coef_mat <- t(as.matrix(coef_mat))
     }
     if (!is(se_mat)[1] == "matrix") {
       se_mat <- t(as.matrix(se_mat))
     }
     # Compute initial estimate
     #init_param <- apply(coef_mat, 2, mean, na.rm = TRUE)
     weights_ <-  apply(se_mat, 2, function(x) { (1 / x) / sum(1 / x) })
     eta_init  <- colSums(coef_mat * weights_)
     se_init <- colSums(se_mat * weights_)
     if (sum(is.nan(eta_init)) > 1) eta_init <- c(logit(mean(dens_vect)),rep(0,n_terms-1))
     init_param <- list(init_param = eta_init, init_se = se_init)
     return(init_param)
}


# compute_initial_parameters_curved_first <- function(obj) {
#      estimate_ <- "CD"
#      suff_sizes <- numeric(length(obj$net_list))
#      for (i in 1:length(obj$net_list)) {
#         cur_net <- obj$net_list[[i]]
#         form_ <- as.formula(paste("cur_net ~ ", paste(deparse(obj$form[[3]]), collapse = "")))
#         suff_sizes[i] <- length(summary(form_))
#      }
#      largest_ <- obj$net_list[[which.max(suff_sizes)]]
#      form <- paste("largest_ ~ ", paste(obj$mod_names[[1]], collapse = "+"))
#      form <- as.formula(form)
#      model_ <- ergm.getmodel(form_, largest_)
#      eta_map <- ergm.etamap(model_)
#      suppressWarnings(invisible(capture.output(
#        get_init_size <- length(ergm(form, eval.loglik = FALSE, estimate = estimate_)$coef)
#      )))
#      n_terms <- get_init_size
#      coef_mat <- matrix(0, nrow = length(obj$net_list), ncol = n_terms)
#      se_mat <- coef_mat
#      dens_vect <- numeric(length(obj$net_list))
#      for (i in 1:nrow(coef_mat)) {
#        form <- paste("cur_net ~ ", paste(obj$mod_names[[i]], collapse = "+"))
#        form <- as.formula(form)
#        cur_net <- obj$net_list[[i]]
#        density_ <- summary(cur_net ~ density)
#        dens_vect[i] <- density_
#        if (density_ != 1 && density_ != 0) {
#          suppressWarnings(invisible(capture.output(
#            if (obj$parameterization == "size") {
#              temp_cur_nte_mtx <- as.matrix(cur_net)
#              res <- ergm(form, estimate =  estimate_)
#              param_est <- res$coef
#              param_est[eta_map$canonical] <- res$coef[eta_map$canonical] / log_fun(nrow(temp_cur_nte_mtx))
#              which_ <- which(eta_map$canonical == 0)
#              param_est[which_[1]] <- param_est[which_[1]] / log_fun(nrow(temp_cur_nte_mtx))
#              se_est <- sqrt(diag(res$covar))
#            } else {
#              res <- ergm(form, estimate = obj$estimate)
#              param_est <- res$coef
#              se_est <- sqrt(diag(res$covar))
#            })))
#            coef_mat[i, ] <- param_est
#            se_mat[i, ] <- se_est
#          } else {
#            coef_mat[i, ] <- rep(100, n_terms)
#            coef_mat[i, ] <- rep(100, n_terms)
#          }
#        }
#
#      # Remove bad initializations
#      bad_mat <- which(apply(coef_mat,1, function(x) sqrt(sum(x^2)/length(x))) > 4)
#      if (length(bad_mat) == nrow(coef_mat)) {
#        cat("\n\n Initial estimates are highly inaccurate.
#            Proposed model may not be appropriate for this network.")
#      }
#      if (length(bad_mat) > 0 & (length(bad_mat) != nrow(coef_mat))) {
#        coef_mat <-  coef_mat[-bad_mat, ]
#        se_mat <- se_mat[-bad_mat, ]
#      }
#
#      if (!is(coef_mat)[1] == "matrix") {
#        coef_mat <- t(as.matrix(coef_mat))
#      }
#      if (!is(se_mat)[1] == "matrix") {
#        se_mat <- t(as.matrix(se_mat))
#      }
#      # Compute initial estimate
#      #init_param <- apply(coef_mat, 2, mean, na.rm = TRUE)
#      weights_ <- (1 / se_mat) / colSums(1 / se_mat)
#      eta_init  <- colSums(coef_mat * weights_)
#      se_init <- colSums(se_mat * weights_)
#      if (sum(is.nan(eta_init)) > 1) eta_init <- c(logit(mean(dens_vect)),rep(0,n_terms-1))
#      init_param <- list(init_param = eta_init, init_se = se_init)
#      return(init_param)
# }
