
initialize_object <- function(net_list,
                              model,
                              eta_init,
                              #eta_grad,
                              #eta_fun,
                              model_size,
                              etamap, 
                              sim_param,
                              est_param,
                              dims) {

  # Create object top structure
  obj <- list(net = NULL,
              sim = NULL,
              est = NULL)

  # Construct obj$net
  obj$net <- list(num_clust = length(net_list),
                  clust_sizes = numeric(length(net_list)),
                  model = model,
                  net_list = net_list,
                  dims = dims,
                  num_terms = model_size,
                  na_flag = FALSE,
                  na_clust_flag = vector(length = length(net_list)),
                  obs_stats = NULL,
                  obs_stats_step = NULL,
                  etamap = etamap)

  # Fill in the number of nodes in each cluster
  for (i in 1:obj$net$num_clust) {
    obj$net$clust_sizes[i] <- obj$net$net_list[[i]]$gal$n
  }

  # Check if there are missing edges
  for (i in 1:obj$net$num_clust) {
    if (network.naedgecount(obj$net$net_list[[i]]) > 0) {
      obj$net$na_clust_flag[i] <- TRUE
    } else {
      obj$net$na_clust_flag[i] <- FALSE
    }
  }

  if (sum(obj$net$na_clust_flag == TRUE) > 0) {
    obj$net$na_flag <- TRUE
  }

  if (!obj$net$na_flag) {
    obj$net$obs_stats <- numeric(obj$net$num_terms)
  }

  # Construct obj$sim
  obj$sim <- sim_param
  obj$sim$stats <- rep(list(matrix(0, nrow = obj$sim$num_obs,
                             ncol = obj$net$num_terms)), obj$net$num_clust)
  if (obj$net$na_flag) {
    obj$sim$cond_stats <- obj$sim$stats
  }


  # Construct obj$est
  # obj$est <- list(eta = eta_init,
  #                 eta_0 = eta_init,
  #                 eta_grad = eta_grad,
  #                 eta_fun = eta_fun,
  #                 score_val = NULL,
  #                 NR_tol = 1e-8,
  #                 NR_iter = 1,
  #                 NR_max_iter = 100,
  #                 NR_status = FALSE,
  #                 MCMLE_iter = 1,
  #                 MCMLE_max_iter = 4,
  #                 MCMLE_tol = 1e-4,
  #                 MCMLE_status = FALSE,
  #                 info_mat = NULL,
  #                 NR_step_len = 1,
  #                 NR_conv_thresh = NULL,
  #                 MCMLE_conv_thresh = NULL,
  #                 par_flag = par_comp,
  #                 par_n_cores = par_n_cores)
  obj$est           <- est_param
  obj$est$eta       <- eta_init
  obj$est$eta_0     <- eta_init
  obj$est$sizes     <- NULL
  obj$est$gamma     <- 1
  #obj$est$eta_grad  <- eta_grad
  #obj$est$eta_fun   <- eta_fun
  obj$est$score_val <- NULL
  for (i in 1:obj$net$num_clust) {
    obj$est$sizes[i] <- obj$net$net_list[[i]]$gal$n
  }

  return(obj)
}
